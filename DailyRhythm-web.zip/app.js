'use strict';
(() => {
/* =====================================================================================
 * Daily Rhythm (web). 100% local: data lives in this browser's localStorage only.
 * MODEL (same as the Android version)
 *   timetables = reusable TEMPLATES; schedule = which template is in force from which day;
 *   days[n]    = a frozen COPY of the template made when day n is first recorded, holding that
 *                day's check marks. Editing a template never changes already-recorded days.
 * ===================================================================================== */
const DAY = 864e5;
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const dayOfDate = d => Math.floor(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / DAY);
const todayN = () => dayOfDate(new Date());
const utc = n => new Date(n * DAY);
const fmtDay = (n, o) => utc(n).toLocaleDateString(undefined, { timeZone: 'UTC', ...o });
const bySort = (a, b) => (a.sort - b.sort) || (a.id - b.id);
const fmtTime = min => { const m = ((min % 1440) + 1440) % 1440, h = Math.floor(m / 60), h12 = h % 12 === 0 ? 12 : h % 12; return `${h12}:${String(m % 60).padStart(2, '0')} ${h < 12 ? 'AM' : 'PM'}`; };
const timeRange = (s, e) => s == null && e == null ? '' : s == null ? 'Until ' + fmtTime(e) : e == null ? fmtTime(s) : fmtTime(s) + ' – ' + fmtTime(e);
const hhmm = m => m == null ? '' : String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0');
const parseHHMM = v => { if (!v) return null; const [h, m] = v.split(':').map(Number); return h * 60 + m; };
const SVG_CHECK = '<svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';

/* ------------------------------------------------------------------ storage */
const K_CFG = 'dr.cfg', K_DAY = 'dr.d.', K_LAST = 'dr.last';
let S;            // config: settings, timetables, template tasks, schedule
const D = {};     // recorded days: n -> { tt, rows: [...] }
const V = { tab: 'today', day: 0, month: null, ttOpen: null, edit: null, confirmFn: null, missed: [], installEv: null };
const nid = () => S.nextId++;

function put(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { toast('Storage full or blocked — export a backup'); } }
const saveCfg = () => put(K_CFG, S);
const saveDay = n => put(K_DAY + n, D[n]);
const delDay = n => { delete D[n]; try { localStorage.removeItem(K_DAY + n); } catch (e) { /* ignore */ } };

function seed() {
  const tt = nid();
  S.timetables.push({ id: tt, name: 'Daily routine', archived: false });
  let order = 0;
  const hm = (h, m) => h * 60 + m;
  const block = (title, s, e, note = '', o = {}) => {
    const id = nid();
    S.tasks.push({ id, tt, parent: null, title, note, s, e, choices: o.choices || '', sort: ++order, enabled: true, emph: !!o.emph });
    (o.kids || []).forEach(([n, d]) => S.tasks.push({ id: nid(), tt, parent: id, title: n, note: d, s: null, e: null, choices: '', sort: ++order, enabled: true, emph: false }));
  };
  block('Morning routine', hm(7, 0), hm(9, 30), 'Morning reset and fitness', { kids: [
    ['Wake up', ''], ['Lukewarm water', '10 min'], ['Brush', '10 min'], ['Washroom', '15 min'], ['Stretching', '15 min'],
    ['Strength training', '20 min'], ['Cardio', '15–20 min'], ['Rest', '15 min'], ['Shower', '20 min']] });
  block('Breakfast', hm(9, 30), hm(10, 15), '', { kids: [['Tea', ''], ['Breakfast', ''], ['Rest', '']] });
  block('Study', hm(10, 20), hm(13, 0), 'Dedicated learning and professional development', { emph: true });
  block('Lunch', hm(13, 10), hm(13, 30), 'Lunch break');
  block('Afternoon reset', hm(13, 30), hm(14, 0), 'Nap or call home', { choices: 'Nap,Call home' });
  block('Work', hm(14, 0), hm(23, 0), 'Rest as per workload.');
  block('Dinner', hm(21, 15), null, 'Dinner break during working hours');
  block('Personal time', hm(23, 0), 0, 'Quality time', { emph: true });
  S.schedule.push({ from: todayN(), tt });
}

function load() {
  try { S = JSON.parse(localStorage.getItem(K_CFG)); } catch (e) { S = null; }
  if (!S || !Array.isArray(S.timetables)) {
    S = { v: 1, nextId: 1, settings: {}, timetables: [], tasks: [], schedule: [] };
    seed();
  }
  S.settings = Object.assign({ theme: 0, sound: true, volume: 60, reminders: true, wake: false }, S.settings);
  saveCfg();
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(K_DAY)) D[+k.slice(K_DAY.length)] = JSON.parse(localStorage.getItem(k));
    }
  } catch (e) { /* ignore corrupt day */ }
}

/* ------------------------------------------------------------------ model */
function resolveTT(day) {
  const sc = S.schedule;
  let best = null;
  for (const e of sc) if (e.from <= day && (!best || e.from > best.from)) best = e;
  if (best) return best.tt;
  return sc.length ? sc.reduce((a, b) => (b.from < a.from ? b : a)).tt : null;
}
const tplTasks = tt => S.tasks.filter(t => t.tt === tt).sort(bySort);
const mkRow = (t, parent) => ({ id: nid(), src: t.id, parent, title: t.title, note: t.note || '', s: t.s, e: t.e, choices: t.choices || '', sort: t.sort, emph: !!t.emph, done: false, choice: null });

function instantiate(day, tt) {
  const tpl = tplTasks(tt).filter(t => t.enabled), rows = [], map = new Map();
  for (const t of tpl) if (t.parent == null) { const r = mkRow(t, null); rows.push(r); map.set(t.id, r.id); }
  for (const t of tpl) if (t.parent != null && map.has(t.parent)) rows.push(mkRow(t, map.get(t.parent)));
  D[day] = { tt, rows }; saveDay(day);
}
function materialize(day) { if (D[day]) return; const tt = resolveTT(day); if (tt != null) instantiate(day, tt); }
function throughToday() {
  if (!S.schedule.length) return;
  const t = todayN(), keys = Object.keys(D).map(Number);
  let start = keys.length ? Math.max(...keys) + 1 : Math.min(...S.schedule.map(e => e.from));
  if (t - start > 3650) start = t - 3650;
  for (let d = start; d <= t; d++) materialize(d);
}
function rebuild(day, tt) { delDay(day); instantiate(day, tt); }

function resync(day) {   // re-apply template edits to an already recorded day, KEEPING check marks
  const p = D[day]; if (!p) return;
  const tpl = tplTasks(p.tt).filter(t => t.enabled);
  const bySrc = new Map(p.rows.filter(r => r.src != null).map(r => [r.src, r])), map = new Map();
  const apply = (r, t, parent) => Object.assign(r, { parent, title: t.title, note: t.note || '', s: t.s, e: t.e, choices: t.choices || '', sort: t.sort, emph: !!t.emph });
  for (const t of tpl) if (t.parent == null) {
    const ex = bySrc.get(t.id);
    if (ex) { apply(ex, t, null); map.set(t.id, ex.id); } else { const r = mkRow(t, null); p.rows.push(r); map.set(t.id, r.id); }
  }
  for (const t of tpl) if (t.parent != null) {
    const pid = map.get(t.parent); if (pid == null) continue;
    const ex = bySrc.get(t.id); if (ex) apply(ex, t, pid); else p.rows.push(mkRow(t, pid));
  }
  const keep = new Set(tpl.map(t => t.id)), del = new Set();
  for (const r of p.rows) if (r.src == null || !keep.has(r.src)) {
    if (!r.done && !p.rows.some(c => c.parent === r.id && c.done)) del.add(r.id);
  }
  let rest = p.rows.filter(r => !del.has(r.id));
  const live = new Set(rest.map(r => r.id));
  p.rows = rest.filter(r => r.parent == null || live.has(r.parent));
  saveDay(day);
}

/** Every structural edit: freeze all days up to today FIRST, then edit, then re-sync today if it uses this template. */
function editing(tt, fn) {
  throughToday(); fn();
  const td = todayN(); if (D[td] && D[td].tt === tt) resync(td);
  saveCfg(); armReminders(); render();
}
function createTT(name, copyFrom) {
  const id = nid(); S.timetables.push({ id, name: name.trim(), archived: false });
  if (copyFrom != null) {
    const src = tplTasks(copyFrom), map = new Map();
    for (const t of src) if (t.parent == null) { const n = Object.assign({}, t, { id: nid(), tt: id }); map.set(t.id, n.id); S.tasks.push(n); }
    for (const t of src) if (t.parent != null && map.has(t.parent)) S.tasks.push(Object.assign({}, t, { id: nid(), tt: id, parent: map.get(t.parent) }));
  }
  saveCfg(); return id;
}
function archiveTT(id) {
  throughToday();
  const t = todayN();
  if (resolveTT(t) === id || S.schedule.some(e => e.from > t && e.tt === id)) return 'Switch to another timetable first';
  if (S.timetables.filter(x => !x.archived).length <= 1) return 'Keep at least one timetable';
  S.timetables.find(x => x.id === id).archived = true; saveCfg(); return null;
}
function setActive(tt, tomorrow) {
  throughToday();
  const t = todayN(), f = t + (tomorrow ? 1 : 0);
  S.schedule = S.schedule.filter(e => e.from < f); S.schedule.push({ from: f, tt });
  if (!tomorrow && !(D[t] && D[t].tt === tt)) rebuild(t, tt);
  saveCfg(); armReminders();
}
function switchDay(day, tt) { throughToday(); if (!(D[day] && D[day].tt === tt)) rebuild(day, tt); armReminders(); }

function buildDay(rows) {
  const sorted = [...rows].sort(bySort), kids = new Map();
  for (const r of sorted) if (r.parent != null) { if (!kids.has(r.parent)) kids.set(r.parent, []); kids.get(r.parent).push(r); }
  return sorted.filter(r => r.parent == null).map(t => {
    const ch = kids.get(t.id) || [];
    return { task: t, children: ch, done: ch.length ? ch.every(c => c.done) : t.done, doneCount: ch.filter(c => c.done).length };
  });
}
const statsOf = items => { const total = items.length, done = items.filter(i => i.done).length; return { total, done, pending: total - done, pct: total ? Math.floor(done * 100 / total) : 0 }; };
const motivation = s => s.total === 0 ? 'Nothing scheduled.' : s.pct === 100 ? 'Beautifully done.' : s.pct >= 75 ? 'Strong day — almost there.' : s.pct >= 40 ? 'Good rhythm. Keep going.' : s.pct > 0 ? 'A gentle start counts.' : 'A fresh page.';

function computeHistory(y, m0) {
  const today = todayN(), first = dayOfDate(new Date(y, m0, 1)), last = Math.min(dayOfDate(new Date(y, m0 + 1, 0)), today);
  const itemsFor = d => D[d] ? buildDay(D[d].rows) : null;
  const days = {}, rates = new Map(); let sum = 0, n = 0, perfect = 0;
  for (let d = first; d <= last; d++) {
    const it = itemsFor(d); if (!it) continue;
    const s = statsOf(it); days[d] = s;
    if (s.total > 0) { sum += s.pct; n++; if (s.pct === 100) perfect++; }
    for (const i of it) { const r = rates.get(i.task.title) || [0, 0]; r[0]++; if (i.done) r[1]++; rates.set(i.task.title, r); }
  }
  let streak = 0, d = today; const ti = itemsFor(d);
  if (!ti || statsOf(ti).pct < 50) d--;
  for (;;) { const it = itemsFor(d); if (!it || statsOf(it).pct < 50) break; streak++; d--; }
  const rated = [...rates].filter(([, v]) => v[0] >= 3).map(([title, v]) => ({ title, pct: Math.floor(v[1] * 100 / v[0]) }));
  const best = rated.reduce((a, b) => (!a || b.pct > a.pct ? b : a), null);
  let worst = rated.reduce((a, b) => (!a || b.pct < a.pct ? b : a), null);
  if (!(rated.length > 1 && worst && worst.pct < 100)) worst = null;
  const week = []; for (let k = today - 6; k <= today; k++) { const it = itemsFor(k); week.push({ day: k, s: it ? statsOf(it) : null }); }
  return { days, monthAvg: n ? Math.floor(sum / n) : 0, perfect, tracked: n, streak, best, worst, week };
}

/* ------------------------------------------------------------------ sound + reminders */
let ac = null;
function audio() {
  if (!ac) { const C = window.AudioContext || window.webkitAudioContext; if (C) ac = new C(); }
  if (ac && ac.state === 'suspended') ac.resume();
  return ac;
}
function chime(start, vol) {
  vol = vol == null ? S.settings.volume : vol;
  const a = audio(); if (!a || vol <= 0) return;
  const g = Math.pow(vol / 100, 2) * 0.5, t0 = a.currentTime + 0.02;
  const notes = start ? [[659.25, 0], [880, 0.16]] : [[783.99, 0], [587.33, 0.18]];
  for (const [f, o] of notes) for (const [m, amp, dur] of [[1, 1, 1.0], [2, .25, .5], [3, .1, .35]]) {
    const osc = a.createOscillator(), gn = a.createGain(), t = t0 + o;
    osc.type = 'sine'; osc.frequency.value = f * m;
    gn.gain.setValueAtTime(0.0001, t); gn.gain.linearRampToValueAtTime(g * amp * 0.6, t + 0.01); gn.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    osc.connect(gn); gn.connect(a.destination); osc.start(t); osc.stop(t + dur + 0.05);
  }
}

const atMs = (day, min) => { const d = utc(day); return new Date(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate(), Math.floor(min / 60), min % 60).getTime(); };
function reminderTasksFor(day) {
  if (D[day]) return D[day].rows.filter(r => r.parent == null);
  const tt = resolveTT(day); return tt == null ? [] : tplTasks(tt).filter(t => t.enabled && t.parent == null);
}
function eventsForDate(day) {   // a block ending at/before its start ends after midnight -> next day
  const out = [];
  for (const t of reminderTasksFor(day)) {
    if (t.s != null) out.push({ at: atMs(day, t.s), t, start: true });
    if (t.e != null) out.push({ at: atMs(day + (t.s != null && t.e <= t.s ? 1 : 0), t.e), t, start: false });
  }
  return out;
}
function eventsBetween(from, to) {
  const out = [], d0 = dayOfDate(new Date(from)), d1 = dayOfDate(new Date(to));
  for (let d = d0 - 1; d <= d1 + 1; d++) for (const e of eventsForDate(d)) if (e.at > from && e.at <= to) out.push(e);
  return out.sort((a, b) => a.at - b.at);
}
let rt = null, lastChecked = Date.now();
function armReminders() {
  clearTimeout(rt);
  if (!S.settings.reminders) return;
  const now = Date.now(), t = todayN();
  let next = Infinity;
  for (let d = t - 1; d <= t + 7; d++) for (const e of eventsForDate(d)) if (e.at > now && e.at < next) next = e.at;
  if (next === Infinity) return;
  rt = setTimeout(tick, Math.max(500, Math.min(next - now + 300, 6 * 3600e3)));
}
function tick() {
  const now = Date.now(); let last = Math.max(lastChecked, now - 12 * 3600e3);
  lastChecked = now; try { localStorage.setItem(K_LAST, String(now)); } catch (e) { /* ignore */ }
  if (S.settings.reminders) {
    const due = eventsBetween(last, now), live = [], missed = [];
    for (const e of due) (now - e.at <= 90e3 ? live : missed).push(e);
    if (live.length) fireLive(live);
    if (missed.length) { V.missed = missed.map(e => `${e.t.title} ${e.start ? 'started' : 'ended'} at ${fmtTime(e.start ? e.t.s : e.t.e)}`); if (V.tab === 'today') render(); }
  }
  armReminders();
}
function fireLive(list) {
  const lines = list.map(e => `${e.t.title} ${e.start ? 'started' : 'completed'}`);
  toast(lines.join(' · '), 5000);
  if (S.settings.sound) chime(list.some(e => e.start));
  for (const e of list) notify(`${e.t.title} ${e.start ? 'started' : 'completed'}`, e.t.note || timeRange(e.t.s, e.t.e), 'dr-' + e.at + '-' + e.t.title);
}
async function notify(title, body, tag) {
  if (!('Notification' in window) || Notification.permission !== 'granted') return;
  try { const reg = await navigator.serviceWorker.ready; reg.showNotification(title, { body, tag, icon: 'icon-192.png', badge: 'icon-192.png', silent: true }); } catch (e) { /* ignore */ }
}
let wake = null;
async function applyWake() {
  try {
    if (S.settings.wake && 'wakeLock' in navigator && document.visibilityState === 'visible') { if (!wake) { wake = await navigator.wakeLock.request('screen'); wake.addEventListener('release', () => { wake = null; }); } }
    else if (wake) { await wake.release(); wake = null; }
  } catch (e) { wake = null; }
}

/* ------------------------------------------------------------------ calendar file (reliable reminders) */
function buildICS() {
  const tt = resolveTT(todayN()), t0 = utc(todayN()), pad = n => String(n).padStart(2, '0');
  const ymd = `${t0.getUTCFullYear()}${pad(t0.getUTCMonth() + 1)}${pad(t0.getUTCDate())}`;
  const txt = s => String(s || '').replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\n/g, '\\n');
  const stamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d+/, '');
  const L = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Daily Rhythm//EN', 'CALSCALE:GREGORIAN'];
  for (const t of tplTasks(tt).filter(x => x.enabled && x.parent == null && x.s != null)) {
    const dur = t.e == null ? 15 : (t.e <= t.s ? t.e + 1440 - t.s : t.e - t.s);
    L.push('BEGIN:VEVENT', `UID:dr-${tt}-${t.id}@dailyrhythm.local`, `DTSTAMP:${stamp}`, `DTSTART:${ymd}T${pad(Math.floor(t.s / 60))}${pad(t.s % 60)}00`,
      `DURATION:PT${dur}M`, 'RRULE:FREQ=DAILY', `SUMMARY:${txt(t.title)}`, `DESCRIPTION:${txt(t.note)}`,
      'BEGIN:VALARM', 'TRIGGER:PT0M', 'ACTION:DISPLAY', `DESCRIPTION:${txt(t.title)} started`, 'END:VALARM');
    if (t.e != null) L.push('BEGIN:VALARM', 'TRIGGER;RELATED=END:PT0M', 'ACTION:DISPLAY', `DESCRIPTION:${txt(t.title)} completed`, 'END:VALARM');
    L.push('END:VEVENT');
  }
  L.push('END:VCALENDAR'); return L.join('\r\n');
}
function download(name, text, type) {
  const a = document.createElement('a'), url = URL.createObjectURL(new Blob([text], { type }));
  a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 4000);
}

/* ------------------------------------------------------------------ UI helpers */
let toastT = null;
function toast(msg, ms = 2600) { const t = $('#toast'); t.textContent = msg; t.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => { t.hidden = true; }, ms); }
const openModal = html => { const m = $('#modal'); m.innerHTML = `<div class="scrim" data-a="mclose"></div><div class="sheet" role="dialog" aria-modal="true">${html}</div>`; m.hidden = false; const f = $('#modal input[type=text]'); if (f && !f.value) setTimeout(() => f.focus(), 50); };
const closeModal = () => { const m = $('#modal'); m.hidden = true; m.innerHTML = ''; };
function ask(title, text, ok, fn) { V.confirmFn = fn; openModal(`<h2>${esc(title)}</h2><p class="muted">${esc(text)}</p><div class="actions"><button class="btn txt" data-a="mclose">Cancel</button><button class="btn pri" data-a="cok">${esc(ok)}</button></div>`); }
function applyTheme() {
  const th = S.settings.theme, r = document.documentElement;
  if (th === 1) r.dataset.theme = 'light'; else if (th === 2) r.dataset.theme = 'dark'; else delete r.dataset.theme;
  const dark = th === 2 || (th === 0 && matchMedia('(prefers-color-scheme: dark)').matches);
  $('meta[name=theme-color]').content = dark ? '#0E1513' : '#F6F0E4';
}
const ttName = id => { const t = S.timetables.find(x => x.id === id); return t ? t.name : 'Timetable'; };
const activeTTs = () => S.timetables.filter(t => !t.archived);

/* ------------------------------------------------------------------ views */
function viewToday() {
  materialize(V.day);
  const today = todayN(), p = D[V.day], items = p ? buildDay(p.rows) : [], st = statsOf(items), isToday = V.day === today;
  let h = `<div class="head"><button class="iconbtn" data-a="prev" aria-label="Previous day"><svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7"/></svg></button>
    <div class="grow center"><h1>${esc(fmtDay(V.day, { weekday: 'long' }))}</h1><p class="muted">${esc(fmtDay(V.day, { day: 'numeric', month: 'long', year: 'numeric' }))}</p></div>
    <button class="iconbtn" data-a="next" aria-label="Next day" ${V.day >= today ? 'disabled' : ''}><svg viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"/></svg></button></div>
    <div class="pills"><button class="pill" data-a="pickTT">${esc(p ? ttName(p.tt) : 'Timetable')} ▾</button>${isToday ? '' : '<button class="pill" data-a="goToday">Back to today</button>'}</div>
    ${isToday ? '' : '<p class="muted center" style="margin-top:-6px">Editing a past record</p>'}`;
  h += '<div class="gap">';
  if (V.missed.length) h += `<div class="card warn"><div class="eyebrow">While you were away</div><p class="muted">${V.missed.map(esc).join('<br>')}</p><div class="actions" style="display:flex;justify-content:flex-end"><button class="btn txt" data-a="dismissMissed">Dismiss</button></div></div>`;
  h += `<div class="hero"><div class="eyebrow">${isToday ? "TODAY'S PROGRESS" : 'PROGRESS · ' + esc(fmtDay(V.day, { day: 'numeric', month: 'short' }).toUpperCase())}</div>
    <p style="margin:10px 0 0;font-weight:600">${st.done} / ${st.total} ACTIVITIES COMPLETED</p>
    <div class="row" style="align-items:flex-end;gap:8px"><span class="big">${st.pct}%</span><span class="eyebrow" style="padding-bottom:10px">COMPLETE</span></div>
    <div class="bar"><i data-w="${st.pct}"></i></div><div style="font-size:13px;opacity:.85">${st.pending} pending · ${esc(motivation(st))}</div></div>`;
  for (const it of items) {
    const t = it.task, rng = timeRange(t.s, t.e), opts = (t.choices || '').split(',').map(x => x.trim()).filter(Boolean);
    h += `<section class="card ${t.emph ? 'emph' : ''}"><div class="row"><div class="grow">${rng ? `<div class="eyebrow">${esc(rng)}</div>` : ''}
      ${t.emph ? `<h2>${esc(t.title)}</h2>` : `<h3>${esc(t.title)}</h3>`}${t.note ? `<p class="muted">${esc(t.note)}</p>` : ''}
      ${it.children.length ? `<p class="muted" style="color:var(--pri)">${it.doneCount} of ${it.children.length} done</p>` : ''}</div>
      <button class="hit" data-a="blk" data-id="${t.id}" aria-label="Toggle ${esc(t.title)}" aria-pressed="${it.done}"><span class="check ${it.done ? 'on' : ''}">${SVG_CHECK}</span></button></div>`;
    if (opts.length) h += `<div class="chips">${opts.map(o => `<button class="chip ${it.done && t.choice === o ? 'on' : ''}" data-a="choice" data-id="${t.id}" data-v="${esc(o)}">${esc(o)}</button>`).join('')}</div>`;
    if (it.children.length) {
      h += '<hr>';
      for (const c of it.children) h += `<button class="child" data-a="child" data-id="${c.id}"><span class="check sm ${c.done ? 'on' : ''}">${SVG_CHECK}</span><span class="t">${esc(c.title)}</span>${c.note ? `<small>${esc(c.note)}</small>` : ''}</button>`;
    }
    h += '</section>';
  }
  if (!items.length) h += '<div class="card center"><p class="muted">No activities for this day. Add some under Timetables.</p></div>';
  h += `</div><p class="center" style="margin-top:14px"><button class="btn txt" data-a="resetDay" style="color:var(--mut)">Reset this day</button></p>`;
  return h;
}

function viewHistory() {
  const today = todayN(), cur = utc(today);
  if (!V.month) V.month = { y: cur.getUTCFullYear(), m: cur.getUTCMonth() };
  const { y, m } = V.month, H = computeHistory(y, m);
  const first = new Date(y, m, 1), lead = (first.getDay() + 6) % 7, len = new Date(y, m + 1, 0).getDate();
  const isCurMonth = y === cur.getUTCFullYear() && m === cur.getUTCMonth();
  let cal = ['M', 'T', 'W', 'T', 'F', 'S', 'S'].map(w => `<div class="wd center">${w}</div>`).join('') + '<span></span>'.repeat(lead);
  for (let n = 1; n <= len; n++) {
    const d = dayOfDate(new Date(y, m, n)), s = H.days[d], tracked = s && s.total > 0, frac = tracked ? s.pct / 100 : 0;
    cal += `<button class="cell ${tracked ? 't' : ''} ${tracked && frac > .6 ? 'hi' : ''} ${d === today ? 'today' : ''}" data-a="openday" data-d="${d}" data-alpha="${frac}" ${d > today ? 'disabled' : ''}>${n}</button>`;
  }
  const wk = H.week.map(({ day, s }) => `<div><span>${s ? s.pct : '–'}</span><span class="col"><i data-h="${Math.max(4, s ? s.pct : 0)}" ${s && s.pct === 0 ? 'data-faint="1"' : ''}></i></span><span>${esc(fmtDay(day, { weekday: 'narrow' }))}</span></div>`).join('');
  return `<h1 style="margin-bottom:12px">History</h1><div class="gap">
  <div class="card"><div class="row"><button class="iconbtn" data-a="mprev" aria-label="Previous month"><svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7"/></svg></button>
   <h2 class="grow center">${esc(first.toLocaleDateString(undefined, { month: 'long', year: 'numeric' }))}</h2>
   <button class="iconbtn" data-a="mnext" aria-label="Next month" ${isCurMonth ? 'disabled' : ''}><svg viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"/></svg></button></div>
   <div class="cal" style="margin-top:8px">${cal}</div><p class="muted" style="margin-top:10px">Tap any day to view or correct its record. Darker = more completed; pale = not recorded.</p></div>
  <div class="card"><div class="eyebrow">Last 7 days</div><div class="week" style="margin-top:10px">${wk}</div></div>
  <div class="tiles"><div class="card tile"><div class="eyebrow">Month average</div><div class="v">${H.monthAvg}%</div></div><div class="card tile"><div class="eyebrow">Perfect days</div><div class="v">${H.perfect}</div></div>
   <div class="card tile"><div class="eyebrow">Streak (days ≥ 50%)</div><div class="v">${H.streak}</div></div><div class="card tile"><div class="eyebrow">Days tracked</div><div class="v">${H.tracked}</div></div></div>
  <div class="card"><div class="eyebrow">This month</div><p style="margin:8px 0 0">${H.best ? `Most consistent: ${esc(H.best.title)} (${H.best.pct}%)` + (H.worst ? `<br>Most missed: ${esc(H.worst.title)} (${H.worst.pct}% done)` : '') : 'Not enough data yet.'}</p></div></div>`;
}

function viewPlans() { return V.ttOpen != null && S.timetables.some(t => t.id === V.ttOpen && !t.archived) ? viewTTEditor() : viewTTList(); }
function viewTTList() {
  const t = todayN(), activeId = resolveTT(t), up = S.schedule.filter(e => e.from > t).sort((a, b) => b.from - a.from)[0];
  let h = `<h1>Timetables</h1><p class="muted" style="margin:6px 0 12px">A timetable is a template for your days. Each day keeps its own copy, so editing or switching a timetable never changes past records.</p>
   <p><button class="btn" data-a="ttNew">+ New timetable</button></p><div class="gap" style="margin-top:12px">`;
  for (const tt of activeTTs()) {
    const badge = tt.id === activeId ? (up ? 'Active today' : 'Active') : (up && up.tt === tt.id ? 'Starts tomorrow' : '');
    h += `<div class="card"><div class="row"><div class="grow">${badge ? `<div class="eyebrow">${badge}</div>` : ''}<h2>${esc(tt.name)}</h2></div><button class="iconbtn" data-a="ttMenu" data-id="${tt.id}" aria-label="More"><svg viewBox="0 0 24 24"><path d="M12 5h.01M12 12h.01M12 19h.01"/></svg></button></div>
     <div class="row" style="margin-top:10px"><button class="btn" data-a="ttOpen" data-id="${tt.id}">Edit activities</button>${tt.id !== activeId || up ? `<button class="btn line" data-a="ttUse" data-id="${tt.id}">Use…</button>` : ''}</div></div>`;
  }
  return h + '</div>';
}
function viewTTEditor() {
  const tt = S.timetables.find(x => x.id === V.ttOpen), mine = tplTasks(tt.id), top = mine.filter(t => t.parent == null);
  const row = t => `<div class="card ${t.enabled ? '' : 'dim'}" ${t.parent != null ? 'data-sub="1"' : ''}><div class="row"><div class="grow">${timeRange(t.s, t.e) ? `<div class="eyebrow">${esc(timeRange(t.s, t.e))}</div>` : ''}<h3>${esc(t.title)}</h3>${t.note ? `<p class="muted">${esc(t.note)}</p>` : ''}</div>
    <button class="switch ${t.enabled ? 'on' : ''}" role="switch" aria-checked="${t.enabled}" data-a="tEnable" data-id="${t.id}" aria-label="Enable"></button></div>
    <div class="row" style="margin-top:8px"><button class="iconbtn" data-a="tUp" data-id="${t.id}" aria-label="Move up"><svg viewBox="0 0 24 24"><path d="M6 15l6-6 6 6"/></svg></button>
     <button class="iconbtn" data-a="tDown" data-id="${t.id}" aria-label="Move down"><svg viewBox="0 0 24 24"><path d="M6 9l6 6 6-6"/></svg></button><span class="grow"></span>
     <button class="btn txt" data-a="tEdit" data-id="${t.id}">Edit</button><button class="btn txt danger" data-a="tDel" data-id="${t.id}">Delete</button></div></div>`;
  let h = `<div class="head"><button class="iconbtn" data-a="ttBack" aria-label="Back"><svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7"/></svg></button><h2 class="grow">${esc(tt.name)}</h2></div>
   <p class="muted" style="margin-bottom:10px">Edits apply to today and future days. Days already recorded keep their own copy.</p><p><button class="btn" data-a="tAdd">+ Add activity</button></p><div class="gap" style="margin-top:12px">`;
  for (const t of top) {
    h += row(t);
    for (const c of mine.filter(x => x.parent === t.id)) h += `<div class="sub">${row(c)}</div>`;
    h += `<p><button class="btn txt" data-a="tSub" data-id="${t.id}">+ Sub-activity in ${esc(t.title)}</button></p>`;
  }
  return h + '</div>';
}

function viewSettings() {
  const s = S.settings, perm = 'Notification' in window ? Notification.permission : 'unsupported';
  const standalone = matchMedia('(display-mode: standalone)').matches;
  const sw = (a, on, label, sub) => `<button class="setrow" data-a="${a}"><span class="grow"><b>${label}</b><br><span class="muted">${sub}</span></span><span class="switch ${on ? 'on' : ''}"></span></button>`;
  return `<h1 style="margin-bottom:12px">Settings</h1><div class="gap">
  <div class="card"><div class="eyebrow" style="margin-bottom:10px">Theme</div><div class="seg">${['System', 'Light', 'Dark'].map((l, i) => `<button class="${s.theme === i ? 'on' : ''}" data-a="theme" data-v="${i}">${l}</button>`).join('')}</div></div>
  <div class="card"><div class="eyebrow">Reminders &amp; sound</div>
   ${sw('togRem', s.reminders, 'Reminders', 'Start / end alerts while the app is open')}${sw('togSnd', s.sound, 'Notification sound', 'Soft chime: one for start, one for end')}
   ${sw('togWake', s.wake, 'Keep screen awake', 'Helps reminders fire while the app stays open')}
   <p style="margin:8px 0 0"><b>Chime volume: <span id="volv">${s.volume}</span>%</b></p><input type="range" id="vol" min="0" max="100" value="${s.volume}" aria-label="Chime volume">
   <p class="muted">Only affects the chime; your phone's media volume is never changed.</p>
   <div class="row" style="margin-top:8px"><button class="btn line" data-a="testStart">Play start</button><button class="btn line" data-a="testEnd">Play end</button></div></div>
  <div class="card warn"><div class="eyebrow">Be aware</div><p class="muted" style="font-size:14px;margin-top:6px">A web app can only fire reminders while it is open (or recently open). When closed or the phone sleeps, Android may stop it. For reminders that always fire, add your timetable to your phone's Calendar:</p>
   <div class="row" style="margin-top:10px"><button class="btn" data-a="ics">Download calendar file (.ics)</button></div>
   <p class="muted">Open the file with Calendar; it creates daily events with start and end alerts for the timetable active today. Re-import after you change timetables.</p></div>
  <div class="card"><div class="eyebrow">System notifications</div><div class="row" style="margin-top:6px"><span class="grow">Status: <b>${perm}</b></span>${perm === 'default' ? '<button class="btn" data-a="notifPerm">Allow</button>' : ''}</div>
   ${perm === 'denied' ? '<p class="muted">Blocked. Allow notifications for this site in Chrome → ⋮ → Settings → Site settings.</p>' : ''}</div>
  <div class="card"><div class="eyebrow">Install</div><p class="muted" style="font-size:14px;margin-top:6px">${standalone ? 'Installed ✓ — running as an app.' : 'In Chrome tap ⋮ → <b>Install app</b> (or <b>Add to Home screen</b>) to use it like an app, offline.'}</p>${V.installEv && !standalone ? '<button class="btn" data-a="install">Install now</button>' : ''}</div>
  <div class="card"><div class="eyebrow">Backup (you control it)</div><p class="muted" style="margin:6px 0 10px">Your data lives only in this browser. Export a backup file now and then; clearing site data deletes it.</p>
   <div class="row"><button class="btn line" data-a="export">Export</button><button class="btn line" data-a="importPick">Import</button></div><input type="file" id="imp" accept="application/json,.json" hidden></div>
  <div class="card"><div class="eyebrow">Privacy</div><p style="margin:6px 0 0">Daily Rhythm makes no network requests beyond loading its own files, has no analytics, ads or accounts, and stores everything in this browser on this phone.</p></div></div>`;
}

function render() {
  const main = $('#main'), top = main.scrollTop;
  main.innerHTML = V.tab === 'today' ? viewToday() : V.tab === 'history' ? viewHistory() : V.tab === 'plans' ? viewPlans() : viewSettings();
  main.querySelectorAll('[data-w]').forEach(e => { e.style.width = e.dataset.w + '%'; });
  main.querySelectorAll('[data-h]').forEach(e => { e.style.height = e.dataset.h + '%'; if (e.dataset.faint) e.style.opacity = .25; });
  main.querySelectorAll('[data-alpha]').forEach(e => e.style.setProperty('--a', e.dataset.alpha));
  main.querySelectorAll('.sub').forEach(e => { e.style.marginLeft = '22px'; });
  document.querySelectorAll('#nav button').forEach(b => b.classList.toggle('on', b.dataset.t === V.tab));
  main.scrollTop = top;
}
const go = tab => { V.tab = tab; $('#main').scrollTop = 0; render(); };

/* ------------------------------------------------------------------ editors */
function taskModal(t) {
  V.edit = t;
  openModal(`<h2>${t.id ? 'Edit activity' : t.parent != null ? 'New sub-activity' : 'New activity'}</h2>
   <label class="lbl" for="m-title">Title</label><input type="text" id="m-title" value="${esc(t.title)}" maxlength="80">
   <label class="lbl" for="m-note">Description</label><input type="text" id="m-note" value="${esc(t.note)}" maxlength="200">
   <label class="lbl" for="m-s">Start (optional)</label><div class="row"><input type="time" id="m-s" value="${hhmm(t.s)}"><button class="btn txt" data-a="clr" data-f="m-s">Clear</button></div>
   <label class="lbl" for="m-e">End (optional)</label><div class="row"><input type="time" id="m-e" value="${hhmm(t.e)}"><button class="btn txt" data-a="clr" data-f="m-e">Clear</button></div>
   ${t.parent == null ? `<label class="lbl" for="m-c">Options (optional, comma separated)</label><input type="text" id="m-c" placeholder="Nap, Call home" value="${esc(t.choices)}">` : ''}
   <p class="muted">Overlapping times are fine. An end at or before the start means it ends after midnight. A block with no start/end time sends no reminder for it.</p>
   <div class="actions"><button class="btn txt" data-a="mclose">Cancel</button><button class="btn pri" data-a="tSave">Save</button></div>`);
}
function saveTaskFromModal() {
  const t = V.edit, title = $('#m-title').value.trim(); if (!title) { toast('Title is required'); return; }
  const f = { title, note: $('#m-note').value.trim(), s: parseHHMM($('#m-s').value), e: parseHHMM($('#m-e').value), choices: t.parent == null ? $('#m-c').value.trim() : '' };
  closeModal();
  editing(t.tt, () => {
    if (t.id) Object.assign(S.tasks.find(x => x.id === t.id), f);
    else S.tasks.push(Object.assign({ id: nid(), tt: t.tt, parent: t.parent, sort: Math.max(0, ...S.tasks.filter(x => x.tt === t.tt).map(x => x.sort)) + 1, enabled: true, emph: false }, f));
  });
}
function moveTask(id, up) {
  const t = S.tasks.find(x => x.id === id);
  editing(t.tt, () => {
    const sibs = S.tasks.filter(x => x.tt === t.tt && x.parent === t.parent).sort(bySort), i = sibs.findIndex(x => x.id === id), j = up ? i - 1 : i + 1;
    if (i >= 0 && j >= 0 && j < sibs.length) { const a = sibs[i], b = sibs[j]; [a.sort, b.sort] = [b.sort, a.sort]; }
  });
}
function newTTModal(copy) {
  V.edit = { copy: copy == null ? null : copy };
  const opt = (id, label) => `<button class="opt ${V.edit.copy === id ? 'on' : ''}" data-a="ttCopy" data-id="${id == null ? '' : id}"><i></i>${esc(label)}</button>`;
  openModal(`<h2>New timetable</h2><label class="lbl" for="m-name">Name</label><input type="text" id="m-name" maxlength="40" placeholder="e.g. Weekend">
   <div class="eyebrow" style="margin:6px 0">Start from</div>${opt(null, 'Empty')}${activeTTs().map(t => opt(t.id, 'Copy of ' + t.name)).join('')}
   <div class="actions"><button class="btn txt" data-a="mclose">Cancel</button><button class="btn pri" data-a="ttCreate">Create</button></div>`);
}

/* ------------------------------------------------------------------ events */
const byId = id => S.tasks.find(x => x.id === +id);
const dayRow = id => (D[V.day] ? D[V.day].rows.find(r => r.id === +id) : null);
const afterDayChange = () => { saveDay(V.day); render(); };

document.addEventListener('click', e => {
  const el = e.target.closest('[data-a]'); if (!el) return;
  audio();   // first tap unlocks WebAudio
  const a = el.dataset.a, id = el.dataset.id, d = el.dataset;
  switch (a) {
    case 'nav': return go(d.t);
    case 'mclose': return closeModal();
    case 'cok': { const f = V.confirmFn; closeModal(); V.confirmFn = null; if (f) f(); return; }
    // ---- today
    case 'prev': V.day -= 1; return render();
    case 'next': V.day = Math.min(V.day + 1, todayN()); return render();
    case 'goToday': V.day = todayN(); return render();
    case 'dismissMissed': V.missed = []; return render();
    case 'blk': {
      const p = D[V.day], r = dayRow(id), kids = p.rows.filter(x => x.parent === r.id);
      if (kids.length) { const v = !kids.every(c => c.done); kids.forEach(c => { c.done = v; c.choice = null; }); } else { r.done = !r.done; if (!r.done) r.choice = null; }
      return afterDayChange();
    }
    case 'child': { const r = dayRow(id); r.done = !r.done; return afterDayChange(); }
    case 'choice': { const r = dayRow(id); if (r.done && r.choice === d.v) { r.done = false; r.choice = null; } else { r.done = true; r.choice = d.v; } return afterDayChange(); }
    case 'resetDay': return ask('Reset this day?', 'All check marks for this date will be cleared. Other days are not affected.', 'Reset', () => { D[V.day].rows.forEach(r => { r.done = false; r.choice = null; }); afterDayChange(); });
    case 'pickTT': {
      const cur = D[V.day] && D[V.day].tt;
      return openModal(`<h2>Timetable for this day</h2><p class="muted">Switching replaces this day's activities and clears its check marks. Other days are not affected.</p>${activeTTs().map(t => `<button class="opt ${t.id === cur ? 'on' : ''}" data-a="dayTT" data-id="${t.id}" ${t.id === cur ? 'disabled' : ''}><i></i>${esc(t.name)}${t.id === cur ? ' (current)' : ''}</button>`).join('')}<div class="actions"><button class="btn txt" data-a="mclose">Cancel</button></div>`);
    }
    case 'dayTT': closeModal(); switchDay(V.day, +id); return render();
    // ---- history
    case 'mprev': { const m = V.month; V.month = m.m === 0 ? { y: m.y - 1, m: 11 } : { y: m.y, m: m.m - 1 }; return render(); }
    case 'mnext': { const m = V.month; V.month = m.m === 11 ? { y: m.y + 1, m: 0 } : { y: m.y, m: m.m + 1 }; return render(); }
    case 'openday': V.day = +d.d; return go('today');
    // ---- timetables
    case 'ttNew': return newTTModal(null);
    case 'ttCopy': V.edit.copy = id === '' ? null : +id; { const n = $('#m-name').value; newTTModal(V.edit.copy); $('#m-name').value = n; } return;
    case 'ttCreate': { const n = $('#m-name').value.trim(); if (!n) { toast('Name is required'); return; } const nid2 = createTT(n, V.edit.copy); closeModal(); V.ttOpen = nid2; return render(); }
    case 'ttOpen': V.ttOpen = +id; $('#main').scrollTop = 0; return render();
    case 'ttBack': V.ttOpen = null; return render();
    case 'ttMenu': return openModal(`<h2>${esc(ttName(+id))}</h2><button class="opt" data-a="ttRename" data-id="${id}"><i></i>Rename</button><button class="opt" data-a="ttDup" data-id="${id}"><i></i>Duplicate</button><button class="opt" data-a="ttArch" data-id="${id}"><i></i>Archive</button><div class="actions"><button class="btn txt" data-a="mclose">Close</button></div>`);
    case 'ttRename': V.edit = { id: +id }; return openModal(`<h2>Rename timetable</h2><input type="text" id="m-name" maxlength="40" value="${esc(ttName(+id))}"><div class="actions"><button class="btn txt" data-a="mclose">Cancel</button><button class="btn pri" data-a="ttRenameOk">Save</button></div>`);
    case 'ttRenameOk': { const n = $('#m-name').value.trim(); if (!n) return; S.timetables.find(x => x.id === V.edit.id).name = n; saveCfg(); closeModal(); return render(); }
    case 'ttDup': closeModal(); return newTTModal(+id);
    case 'ttArch': closeModal(); return ask(`Archive “${ttName(+id)}”?`, "It disappears from this list. Days already recorded with it keep their activities. You can't archive the timetable currently in use.", 'Archive', () => { const err = archiveTT(+id); if (err) toast(err); armReminders(); render(); });
    case 'ttUse': return openModal(`<h2>Use “${esc(ttName(+id))}”</h2><p class="muted">Earlier days keep the timetable they were recorded with. “From today” replaces today's activities and clears today's check marks.</p><div class="gap"><button class="btn" data-a="ttNow" data-id="${id}">From today</button><button class="btn" data-a="ttTom" data-id="${id}">From tomorrow</button></div><div class="actions"><button class="btn txt" data-a="mclose">Cancel</button></div>`);
    case 'ttNow': closeModal(); setActive(+id, false); return render();
    case 'ttTom': closeModal(); setActive(+id, true); return render();
    case 'tAdd': return taskModal({ id: 0, tt: V.ttOpen, parent: null, title: '', note: '', s: 540, e: 600, choices: '' });
    case 'tSub': return taskModal({ id: 0, tt: V.ttOpen, parent: +id, title: '', note: '', s: null, e: null, choices: '' });
    case 'tEdit': return taskModal(Object.assign({}, byId(id)));
    case 'tSave': return saveTaskFromModal();
    case 'clr': $('#' + d.f).value = ''; return;
    case 'tEnable': { const t = byId(id); return editing(t.tt, () => { t.enabled = !t.enabled; }); }
    case 'tUp': return moveTask(+id, true);
    case 'tDown': return moveTask(+id, false);
    case 'tDel': { const t = byId(id); return ask(`Delete “${t.title}”?`, 'Removed from this timetable from today onward. Past days keep their records.', 'Delete', () => editing(t.tt, () => { S.tasks = S.tasks.filter(x => x.id !== t.id && x.parent !== t.id); })); }
    // ---- settings
    case 'theme': S.settings.theme = +d.v; saveCfg(); applyTheme(); return render();
    case 'togRem': S.settings.reminders = !S.settings.reminders; saveCfg(); armReminders(); if (S.settings.reminders && 'Notification' in window && Notification.permission === 'default') toast('Tip: allow system notifications below'); return render();
    case 'togSnd': S.settings.sound = !S.settings.sound; saveCfg(); return render();
    case 'togWake': S.settings.wake = !S.settings.wake; saveCfg(); applyWake(); return render();
    case 'testStart': return chime(true);
    case 'testEnd': return chime(false);
    case 'notifPerm': Notification.requestPermission().then(render); return;
    case 'install': if (V.installEv) { V.installEv.prompt(); V.installEv = null; } return;
    case 'ics': download('daily-rhythm.ics', buildICS(), 'text/calendar'); return toast('Open the downloaded file with Calendar');
    case 'export': download('daily-rhythm-backup.json', JSON.stringify({ app: 'DailyRhythm-web', v: 1, cfg: S, days: D }), 'application/json'); return toast('Backup saved to your downloads');
    case 'importPick': return $('#imp').click();
  }
});

document.addEventListener('keydown', e => { if (e.key === 'Escape' && !$('#modal').hidden) closeModal(); });
document.addEventListener('input', e => {
  if (e.target.id === 'vol') { S.settings.volume = +e.target.value; $('#volv').textContent = e.target.value; }
});
document.addEventListener('change', e => {
  if (e.target.id === 'vol') { saveCfg(); chime(true); return; }
  if (e.target.id === 'imp' && e.target.files[0]) {
    const file = e.target.files[0]; e.target.value = '';
    file.text().then(txt => {
      let o; try { o = JSON.parse(txt); } catch (err) { return toast('Not a valid backup file'); }
      if (!o || o.app !== 'DailyRhythm-web' || !o.cfg || !Array.isArray(o.cfg.timetables) || typeof o.days !== 'object') return toast('Not a Daily Rhythm backup');
      ask('Replace all data?', 'Importing replaces your current timetables and history with the file.', 'Replace', () => {
        for (const k of Object.keys(D)) delDay(+k);
        S = o.cfg; saveCfg(); S.settings = Object.assign({ theme: 0, sound: true, volume: 60, reminders: true, wake: false }, S.settings);
        for (const [k, v] of Object.entries(o.days)) { D[+k] = v; saveDay(+k); }
        throughToday(); applyTheme(); armReminders(); toast('Backup restored'); render();
      });
    });
  }
});

document.addEventListener('visibilitychange', () => {
  if (document.visibilityState !== 'visible') { try { localStorage.setItem(K_LAST, String(Date.now())); } catch (e) { /* ignore */ } return; }
  const old = todayN() !== V.todayKey; 
  if (old) { if (V.day === V.todayKey) V.day = todayN(); V.todayKey = todayN(); throughToday(); }
  tick(); applyWake(); render();
});
window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); V.installEv = e; if (V.tab === 'settings') render(); });
matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyTheme);

/* ------------------------------------------------------------------ start */
load(); applyTheme(); throughToday();
V.todayKey = todayN(); V.day = V.todayKey;
lastChecked = +localStorage.getItem(K_LAST) || Date.now();
if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => { /* offline cache unavailable */ });
if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => { /* ignore */ });
render(); tick(); applyWake();
window.__dr = { S: () => S, D, todayN, buildDay, statsOf, computeHistory, eventsForDate, resolveTT, setActive, switchDay, editing, createTT, archiveTT, buildICS, tick }; // debug hook for tests only
})();
